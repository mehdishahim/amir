# ![Image](Instagram2016_white-(64px).png) Node.JS Instagram Tools


Original author of this project is man who say himself as "CCOCOT".
He deleted his own repository, then several members of SGBTeam are taking care of development and new features.
And this is collection of several developments that have been carried out so far.

----

### Installation

```
$ git clone https://github.com/masokky/instagram-tools.git
$ cd instagram-tools
$ node index.js
```

----

### Features

* Bot Like Timeline
* Follow Followers Target by People
* Follow Followers Target by Media
* Follow Followers Target by Hastag
* Follow Followers Target by Location
* Follow Followers Target by People - with DM
* Follow Followers Target by People - No Like
* Follow Followers Target by People - No Comment & Like
* Repost Media Target by People
* Repost Media Target by Hashtag
* Repost Media Target by Link
* Comment & Like Followers Target by People
* Comment & Like Followers Target by Hashtag
* Bom Like Target's Post
* Bom Comment Target's Post
* Unfollow Not Followback
* Unfollow All Following
* Delete All Media

----

### Thanks to

* CODE BY CYBER SCREAMER CCOCOT (ccocot@bc0de.net)
* FIXING & TESTING BY SYNTAX (@officialputu_id)
* CCOCOT.CO | BC0DE.NET | NAONLAH.NET | WingkoColi
* SGB TEAM REBORN | Zerobyte.id | ccocot@bc0de.net
* RMT by Mas Okky (@masokky_)
